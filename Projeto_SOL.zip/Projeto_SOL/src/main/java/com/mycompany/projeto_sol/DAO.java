package com.mycompany.projeto_sol;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {

    public boolean existeAdm(LoginAdministrador adm) throws Exception {
        String sql = "SELECT * FROM tb_login_adm WHERE nome = ? AND senha= ?";

        try ( Connection conn = ConexaoBD.obterConexao();  PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, adm.getNome());
            ps.setString(2, adm.getSenha());

            try ( ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void inserirCadastroParceiro(Parceiro cadastro) throws Exception {
        String sql = "INSERT INTO tb_parceiro (nome, tipo, cnpj, endereco, email, telefone) VALUES (?, ?, ?, ?, ?, ? );";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, cadastro.getNome());
            ps.setString(2, cadastro.getTipo());
            ps.setString(3, cadastro.getCnpj());
            ps.setString(4, cadastro.getEndereco());
            ps.setString(5, cadastro.getEmail());
            ps.setString(6, cadastro.getTelefone());
            ps.execute();
        }
    }

    public Parceiro[] obterParceiros() throws Exception {
        String sql = "SELECT * FROM tb_parceiro";
        try ( Connection conn = ConexaoBD.obterConexao();  PreparedStatement ps = conn.prepareStatement(sql,
                ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);  ResultSet rs = ps.executeQuery()) {

            int totalDeParceiros = rs.last() ? rs.getRow() : 0;
            Parceiro[] parceiros = new Parceiro[totalDeParceiros];
            rs.beforeFirst();
            int contador = 0;
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String tipo = rs.getString("tipo");
                String cnpj = rs.getString("cnpj");
                String endereco = rs.getString("endereco");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");

                parceiros[contador++] = new Parceiro(id, nome, tipo, cnpj, endereco, email, telefone);
            }
            return parceiros;
        }
    }

    public void atualizarParceiro(Parceiro parceiro) throws Exception {
        String sql = "UPDATE tb_parceiro SET nome = ?, tipo = ?, cnpj = ?, endereco = ?, email = ?, telefone = ? WHERE id = ?";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, parceiro.getNome());
            ps.setString(2, parceiro.getTipo());
            ps.setString(3, parceiro.getCnpj());
            ps.setString(4, parceiro.getEndereco());
            ps.setString(5, parceiro.getEmail());
            ps.setString(6, parceiro.getTelefone());
            ps.setInt(7, parceiro.getId());
            ps.execute();
        }
    }

    public void removerParceiro(Parceiro parceiro) throws Exception {
        String sql = "DELETE FROM tb_parceiro WHERE id = ?";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql);) {
            ps.setInt(1, parceiro.getId());
            ps.execute();
        }
    }
    
    //Métodos para usuários

    public boolean existeUsuario(LoginUsuario usuario) throws Exception {
        String sql = "SELECT * FROM tb_login_usuario WHERE nome= ? AND senha= ?";

        try ( Connection conn = ConexaoBD.obterConexao();  PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getSenha());

            try ( ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public Usuario[] obterUsuarios() throws Exception {
        String sql = "SELECT * FROM tb_usuario";
        try ( Connection conn = ConexaoBD.obterConexao();  PreparedStatement ps = conn.prepareStatement(sql,
                ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);  ResultSet rs = ps.executeQuery()) {

            int totalDeUsuarios = rs.last() ? rs.getRow() : 0;
            Usuario[] usuarios = new Usuario[totalDeUsuarios];
            rs.beforeFirst();
            int contador = 0;
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String sexo = rs.getString("sexo");
                String nascimento = rs.getString("nascimento");
                String cpf = rs.getString("cpf");
                String endereco = rs.getString("endereco");
                String email = rs.getString("email");
                String telefone = rs.getString("telefone");

                usuarios[contador++] = new Usuario(id, nome, sexo, nascimento, cpf, endereco, email, telefone);
            }
            return usuarios;
        }
    }

    public void inserirCadastroUsuario(Usuario cadastro) throws Exception {
        String sql = "INSERT INTO tb_usuario (nome, sexo, nascimento, cpf, endereco, email, telefone, login, senha, confirmaSenha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, cadastro.getNome());
            ps.setString(2, cadastro.getSexo());
            ps.setString(3, cadastro.getNascimento());
            ps.setString(4, cadastro.getCpf());
            ps.setString(5, cadastro.getEndereco());
            ps.setString(6, cadastro.getEmail());
            ps.setString(7, cadastro.getTelefone());
            ps.setString(8, cadastro.getLogin());
            ps.setString(9, cadastro.getSenha());
            ps.setString(10, cadastro.getConfirmaSenha());
            ps.execute();
        }
    }

    public void atualizarUsuario(Usuario usuario) throws Exception {
        String sql = "UPDATE tb_usuario SET nome = ?, sexo = ?, nascimento = ?, cpf = ?, endereco = ?, email = ?, telefone = ? WHERE id = ?";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql)) {
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getSexo());
            ps.setString(3, usuario.getNascimento());
            ps.setString(4, usuario.getCpf());
            ps.setString(5, usuario.getEndereco());
            ps.setString(6, usuario.getEmail());
            ps.setString(7, usuario.getTelefone());
            ps.setInt(8, usuario.getId());
            ps.execute();
        }
    }

    public void removerUsuario(Usuario usuario) throws Exception {
        String sql = "DELETE FROM tb_usuario WHERE id = ?";
        try ( Connection conexao = ConexaoBD.obterConexao();  PreparedStatement ps = conexao.prepareStatement(sql);) {
            ps.setInt(1, usuario.getId());
            ps.execute();
        }
    }
}
