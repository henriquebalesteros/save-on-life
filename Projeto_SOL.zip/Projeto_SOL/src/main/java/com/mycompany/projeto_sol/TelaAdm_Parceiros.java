package com.mycompany.projeto_sol;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class TelaAdm_Parceiros extends javax.swing.JFrame {

    private void buscarParceiros() {
        try {
            DAO dao = new DAO();
            Parceiro[] parceiros = dao.obterParceiros();
            parceirosComboBox.setModel(new DefaultComboBoxModel<>(parceiros));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Cursos indisponíveis, tente novamente mais tarde.");
            e.printStackTrace();
        }
    }

    public TelaAdm_Parceiros() {
        super("Acesso restrito - Administrador");
        initComponents();
        buscarParceiros();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        idTextField = new javax.swing.JTextField();
        nomeTextField = new javax.swing.JTextField();
        tipoTextField = new javax.swing.JTextField();
        cnpjTextField = new javax.swing.JTextField();
        enderecoTextField = new javax.swing.JTextField();
        emailTextField = new javax.swing.JTextField();
        telefoneTextField = new javax.swing.JTextField();
        parceirosComboBox = new javax.swing.JComboBox();
        CadastrarParceiroButton = new javax.swing.JButton();
        atualizarCadastroParceiroButton = new javax.swing.JButton();
        removerCadastroParceiroButton = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Gerenciador de Parceiros"));

        idTextField.setEditable(false);
        idTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Id"));

        nomeTextField.setEditable(false);
        nomeTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome"));

        tipoTextField.setEditable(false);
        tipoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Tipo"));

        cnpjTextField.setEditable(false);
        cnpjTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("CNPJ"));

        enderecoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Endereço"));

        emailTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("E-mail"));

        telefoneTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone"));

        parceirosComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        parceirosComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parceirosComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nomeTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tipoTextField))
                            .addComponent(cnpjTextField)
                            .addComponent(enderecoTextField)
                            .addComponent(emailTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 155, Short.MAX_VALUE))))
                    .addComponent(parceirosComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(parceirosComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tipoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nomeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cnpjTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(enderecoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(emailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        CadastrarParceiroButton.setText("Novo");
        CadastrarParceiroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarParceiroButtonActionPerformed(evt);
            }
        });

        atualizarCadastroParceiroButton.setText("Atualizar");
        atualizarCadastroParceiroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarCadastroParceiroButtonActionPerformed(evt);
            }
        });

        removerCadastroParceiroButton.setText("Remover");
        removerCadastroParceiroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerCadastroParceiroButtonActionPerformed(evt);
            }
        });

        jButton4.setText("Cancelar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CadastrarParceiroButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(removerCadastroParceiroButton, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(atualizarCadastroParceiroButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CadastrarParceiroButton)
                    .addComponent(atualizarCadastroParceiroButton))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(removerCadastroParceiroButton)
                    .addComponent(jButton4))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void atualizarCadastroParceiroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarCadastroParceiroButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Atualizar cadastro existente?");
        if (escolha == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idTextField.getText());
                String nome = nomeTextField.getText();
                String tipo = tipoTextField.getText();
                String cnpj = cnpjTextField.getText();
                String endereco = enderecoTextField.getText();
                String email = emailTextField.getText();
                String telefone = telefoneTextField.getText();

                Parceiro parceiro = new Parceiro(id, nome, tipo, cnpj, endereco, email, telefone);
                DAO dao = new DAO();
                dao.atualizarParceiro(parceiro);
                JOptionPane.showMessageDialog(null, "Cadastro atualizado com sucesso");
                buscarParceiros();
                idTextField.setText("");
                nomeTextField.setText("");
                tipoTextField.setText("");
                cnpjTextField.setText("");
                enderecoTextField.setText("");
                emailTextField.setText("");
                telefoneTextField.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_atualizarCadastroParceiroButtonActionPerformed

    private void CadastrarParceiroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarParceiroButtonActionPerformed
        TelaCadastroParceiro cadastro = new TelaCadastroParceiro();
        cadastro.setVisible(true);
    }//GEN-LAST:event_CadastrarParceiroButtonActionPerformed

    private void parceirosComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parceirosComboBoxActionPerformed
        Parceiro parceiro = (Parceiro) parceirosComboBox.getSelectedItem();
        idTextField.setText(Integer.toString(parceiro.getId()));
        nomeTextField.setText(parceiro.getNome());
        tipoTextField.setText(parceiro.getTipo());
        cnpjTextField.setText(parceiro.getCnpj());
        enderecoTextField.setText(parceiro.getEndereco());
        emailTextField.setText(parceiro.getEmail());
        telefoneTextField.setText(parceiro.getTelefone());

    }//GEN-LAST:event_parceirosComboBoxActionPerformed

    private void removerCadastroParceiroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerCadastroParceiroButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Remover cadastro?");
        if (escolha == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idTextField.getText());
                Parceiro parceiro = new Parceiro(id);
                DAO dao = new DAO();
                dao.removerParceiro(parceiro);
                JOptionPane.showMessageDialog(null, "Curso removido com sucesso!");
                buscarParceiros();
                nomeTextField.setText("");
                tipoTextField.setText("");
                cnpjTextField.setText("");
                enderecoTextField.setText("");
                emailTextField.setText("");
                telefoneTextField.setText("");
                idTextField.setText("");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_removerCadastroParceiroButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Parceiros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Parceiros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Parceiros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Parceiros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaAdm_Parceiros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CadastrarParceiroButton;
    private javax.swing.JButton atualizarCadastroParceiroButton;
    private javax.swing.JTextField cnpjTextField;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JTextField enderecoTextField;
    private javax.swing.JTextField idTextField;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nomeTextField;
    private javax.swing.JComboBox parceirosComboBox;
    private javax.swing.JButton removerCadastroParceiroButton;
    private javax.swing.JTextField telefoneTextField;
    private javax.swing.JTextField tipoTextField;
    // End of variables declaration//GEN-END:variables
}
