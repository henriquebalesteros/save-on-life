package com.mycompany.projeto_sol;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class TelaUsuario extends javax.swing.JFrame {

    private void buscarUsuarios() {
        try {
            DAO dao = new DAO();
            Usuario[] usuarios = dao.obterUsuarios();
            usuariosComboBox.setModel(new DefaultComboBoxModel<>(usuarios));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Usuarios indisponíveis, tente novamente mais tarde.");
            e.printStackTrace();
        }
    }

    public TelaUsuario() {
        super("Acesso Usuário");
        initComponents();
        buscarUsuarios();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        idTextField = new javax.swing.JTextField();
        nomeTextField = new javax.swing.JTextField();
        cpfTextField = new javax.swing.JTextField();
        nascimentoTextField = new javax.swing.JTextField();
        enderecoTextField = new javax.swing.JTextField();
        emailTextField = new javax.swing.JTextField();
        telefoneTextField = new javax.swing.JTextField();
        usuariosComboBox = new javax.swing.JComboBox();
        sexoTextField = new javax.swing.JTextField();
        atualizarCadastroParceiroButton = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Meus Dados"));

        idTextField.setEditable(false);
        idTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Id"));

        nomeTextField.setEditable(false);
        nomeTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome"));

        cpfTextField.setEditable(false);
        cpfTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("CPF"));

        nascimentoTextField.setEditable(false);
        nascimentoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Data de nascimento"));

        enderecoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Endereço"));

        emailTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("E-mail"));

        telefoneTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone"));

        usuariosComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        usuariosComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuariosComboBoxActionPerformed(evt);
            }
        });

        sexoTextField.setEditable(false);
        sexoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Sexo"));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nomeTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cpfTextField))
                            .addComponent(enderecoTextField)
                            .addComponent(emailTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(nascimentoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(sexoTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))))
                    .addComponent(usuariosComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(usuariosComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cpfTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nomeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nascimentoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sexoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(enderecoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(emailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        atualizarCadastroParceiroButton.setText("Atualizar");
        atualizarCadastroParceiroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarCadastroParceiroButtonActionPerformed(evt);
            }
        });

        jButton4.setText("Cancelar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(atualizarCadastroParceiroButton, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atualizarCadastroParceiroButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void atualizarCadastroParceiroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarCadastroParceiroButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Atualizar cadastro existente?");
        if (escolha == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idTextField.getText());
                String nome = nomeTextField.getText();
                String sexo = sexoTextField.getText();
                String nascimento = nascimentoTextField.getText();
                String cpf = cpfTextField.getText();                
                String endereco = enderecoTextField.getText();
                String email = emailTextField.getText();
                String telefone = telefoneTextField.getText();

                Usuario usuario = new Usuario(id, nome, sexo, nascimento, cpf, endereco, email, telefone);
                DAO dao = new DAO();
                dao.atualizarUsuario(usuario);
                JOptionPane.showMessageDialog(null, "Cadastro atualizado com sucesso");
                buscarUsuarios();
                idTextField.setText("");
                nomeTextField.setText("");
                sexoTextField.setText("");
                nascimentoTextField.setText("");
                cpfTextField.setText("");                
                enderecoTextField.setText("");
                emailTextField.setText("");
                telefoneTextField.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_atualizarCadastroParceiroButtonActionPerformed

    private void usuariosComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuariosComboBoxActionPerformed
        Usuario usuario = (Usuario) usuariosComboBox.getSelectedItem();
        idTextField.setText(Integer.toString(usuario.getId()));
        nomeTextField.setText(usuario.getNome());
        sexoTextField.setText(usuario.getSexo());
        nascimentoTextField.setText(usuario.getNascimento());
        cpfTextField.setText(usuario.getCpf());        
        enderecoTextField.setText(usuario.getEndereco());
        emailTextField.setText(usuario.getEmail());
        telefoneTextField.setText(usuario.getTelefone());

    }//GEN-LAST:event_usuariosComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atualizarCadastroParceiroButton;
    private javax.swing.JTextField cpfTextField;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JTextField enderecoTextField;
    private javax.swing.JTextField idTextField;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nascimentoTextField;
    private javax.swing.JTextField nomeTextField;
    private javax.swing.JTextField sexoTextField;
    private javax.swing.JTextField telefoneTextField;
    private javax.swing.JComboBox usuariosComboBox;
    // End of variables declaration//GEN-END:variables
}
