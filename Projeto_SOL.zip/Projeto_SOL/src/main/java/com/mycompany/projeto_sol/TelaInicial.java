
package com.mycompany.projeto_sol;

public class TelaInicial extends javax.swing.JFrame {

   
    public TelaInicial() {
        super ("Save One Life");
        initComponents();
        setLocationRelativeTo(null);

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cadastroUsuarioButton = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        acessoRestritoMenu = new javax.swing.JMenu();
        usuarioLoginMenuItem = new javax.swing.JMenuItem();
        administradorLoginMenuItem = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setText("Quer fazer parte do grupo SOL");

        jLabel2.setText("Quero ser ajudado pelos parceiros do grupo SOL");

        cadastroUsuarioButton.setBackground(new java.awt.Color(204, 204, 255));
        cadastroUsuarioButton.setText("Cadastre-se");
        cadastroUsuarioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastroUsuarioButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(177, 177, 177)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cadastroUsuarioButton, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addContainerGap(153, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cadastroUsuarioButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        jMenu1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Banco de dados\\Save_One_Life\\src\\main\\java\\imagem\\sol.jpg")); // NOI18N
        jMenu1.setText("SOL");
        jMenuBar1.add(jMenu1);

        jMenu2.setBackground(new java.awt.Color(255, 204, 204));
        jMenu2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Banco de dados\\Save_One_Life\\src\\main\\java\\imagem\\quem.jpg")); // NOI18N
        jMenu2.setText("Quem nós somos");
        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Banco de dados\\Save_One_Life\\src\\main\\java\\imagem\\parceiros.jpg")); // NOI18N
        jMenu3.setText("Parceiros");
        jMenuBar1.add(jMenu3);

        acessoRestritoMenu.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Banco de dados\\Save_One_Life\\src\\main\\java\\imagem\\restrito.jpg")); // NOI18N
        acessoRestritoMenu.setText("Acesso Restrito");

        usuarioLoginMenuItem.setText("Fazer Login");
        usuarioLoginMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioLoginMenuItemActionPerformed(evt);
            }
        });
        acessoRestritoMenu.add(usuarioLoginMenuItem);

        administradorLoginMenuItem.setText("Acesso Administrador");
        administradorLoginMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                administradorLoginMenuItemActionPerformed(evt);
            }
        });
        acessoRestritoMenu.add(administradorLoginMenuItem);

        jMenuBar1.add(acessoRestritoMenu);

        jMenu5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Dell\\Desktop\\Banco de dados\\Save_One_Life\\src\\main\\java\\imagem\\contato.jpg")); // NOI18N
        jMenu5.setText("Contato");
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usuarioLoginMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioLoginMenuItemActionPerformed
        TelaLoginUsuario usuario = new TelaLoginUsuario ();
        usuario.setVisible (true);
        
    }//GEN-LAST:event_usuarioLoginMenuItemActionPerformed

    private void administradorLoginMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_administradorLoginMenuItemActionPerformed
        TelaLoginAdm adm = new TelaLoginAdm ();
        adm.setVisible (true);
        
    }//GEN-LAST:event_administradorLoginMenuItemActionPerformed

    private void cadastroUsuarioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastroUsuarioButtonActionPerformed
        TelaCadastroUsuario novousuario = new TelaCadastroUsuario ();
        novousuario.setVisible (true);
        
    }//GEN-LAST:event_cadastroUsuarioButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu acessoRestritoMenu;
    private javax.swing.JMenuItem administradorLoginMenuItem;
    private javax.swing.JButton cadastroUsuarioButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem usuarioLoginMenuItem;
    // End of variables declaration//GEN-END:variables
}
