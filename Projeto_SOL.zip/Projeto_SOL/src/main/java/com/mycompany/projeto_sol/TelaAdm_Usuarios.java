package com.mycompany.projeto_sol;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class TelaAdm_Usuarios extends javax.swing.JFrame {

    private void buscarUsuarios() {
        try {
            DAO dao = new DAO();
            Parceiro[] parceiros = dao.obterParceiros();
            UsuariosComboBox.setModel(new DefaultComboBoxModel<>(parceiros));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Usuários indisponíveis, tente novamente mais tarde.");
            e.printStackTrace();
        }
    }

    public TelaAdm_Usuarios() {
        super("Acesso restrito - Administrador");
        initComponents();
        buscarUsuarios();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        idTextField = new javax.swing.JTextField();
        nomeTextField = new javax.swing.JTextField();
        cpfTextField = new javax.swing.JTextField();
        nascimentoTextField = new javax.swing.JTextField();
        enderecoTextField = new javax.swing.JTextField();
        emailTextField = new javax.swing.JTextField();
        telefoneTextField = new javax.swing.JTextField();
        UsuariosComboBox = new javax.swing.JComboBox();
        sexoTextField = new javax.swing.JTextField();
        atualizarCadastroUsuarioButton = new javax.swing.JButton();
        removerCadastroUsuarioButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Gerenciador de Parceiros"));

        idTextField.setEditable(false);
        idTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Id"));

        nomeTextField.setEditable(false);
        nomeTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome"));

        cpfTextField.setEditable(false);
        cpfTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("CPF"));

        nascimentoTextField.setEditable(false);
        nascimentoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Nascimento"));

        enderecoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Endereço"));

        emailTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("E-mail"));

        telefoneTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone"));

        UsuariosComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        UsuariosComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsuariosComboBoxActionPerformed(evt);
            }
        });

        sexoTextField.setEditable(false);
        sexoTextField.setBorder(javax.swing.BorderFactory.createTitledBorder("Sexo"));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(UsuariosComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nomeTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cpfTextField))
                            .addComponent(enderecoTextField)
                            .addComponent(emailTextField)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(sexoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(nascimentoTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(UsuariosComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cpfTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nomeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nascimentoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sexoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(enderecoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(emailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(telefoneTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        atualizarCadastroUsuarioButton.setText("Atualizar");
        atualizarCadastroUsuarioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarCadastroUsuarioButtonActionPerformed(evt);
            }
        });

        removerCadastroUsuarioButton.setText("Remover");
        removerCadastroUsuarioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerCadastroUsuarioButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(atualizarCadastroUsuarioButton, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(removerCadastroUsuarioButton, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(atualizarCadastroUsuarioButton)
                    .addComponent(removerCadastroUsuarioButton))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void atualizarCadastroUsuarioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarCadastroUsuarioButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Atualizar cadastro existente?");
        if (escolha == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idTextField.getText());
                String nome = nomeTextField.getText();
                String sexo = sexoTextField.getText();
                String cpf = cpfTextField.getText();                
                String nascimento = nascimentoTextField.getText();
                String endereco = enderecoTextField.getText();
                String email = emailTextField.getText();
                String telefone = telefoneTextField.getText();

                Usuario usuario = new Usuario (nome, sexo, nascimento, cpf, endereco, email, telefone );
                DAO dao = new DAO();
                dao.atualizarUsuario(usuario);
                JOptionPane.showMessageDialog(null, "Cadastro atualizado com sucesso");
                buscarUsuarios();
                idTextField.setText("");
                nomeTextField.setText("");
                cpfTextField.setText("");
                nascimentoTextField.setText("");
                enderecoTextField.setText("");
                emailTextField.setText("");
                telefoneTextField.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_atualizarCadastroUsuarioButtonActionPerformed

    private void UsuariosComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsuariosComboBoxActionPerformed
        Parceiro parceiro = (Parceiro) UsuariosComboBox.getSelectedItem();
        idTextField.setText(Integer.toString(parceiro.getId()));
        nomeTextField.setText(parceiro.getNome());
        cpfTextField.setText(parceiro.getTipo());
        nascimentoTextField.setText(parceiro.getCnpj());
        enderecoTextField.setText(parceiro.getEndereco());
        emailTextField.setText(parceiro.getEmail());
        telefoneTextField.setText(parceiro.getTelefone());

    }//GEN-LAST:event_UsuariosComboBoxActionPerformed

    private void removerCadastroUsuarioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerCadastroUsuarioButtonActionPerformed
        int escolha = JOptionPane.showConfirmDialog(null, "Remover cadastro?");
        if (escolha == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idTextField.getText());
                Parceiro parceiro = new Parceiro(id);
                DAO dao = new DAO();
                dao.removerParceiro(parceiro);
                JOptionPane.showMessageDialog(null, "Cadastro removido com sucesso!");
                buscarUsuarios();
                idTextField.setText("");
                nomeTextField.setText("");
                sexoTextField.setText("");
                cpfTextField.setText("");
                nascimentoTextField.setText("");
                enderecoTextField.setText("");
                emailTextField.setText("");
                telefoneTextField.setText("");
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Falha técnica. Tente novamente mais tarde.");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_removerCadastroUsuarioButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaAdm_Usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaAdm_Usuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox UsuariosComboBox;
    private javax.swing.JButton atualizarCadastroUsuarioButton;
    private javax.swing.JTextField cpfTextField;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JTextField enderecoTextField;
    private javax.swing.JTextField idTextField;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField nascimentoTextField;
    private javax.swing.JTextField nomeTextField;
    private javax.swing.JButton removerCadastroUsuarioButton;
    private javax.swing.JTextField sexoTextField;
    private javax.swing.JTextField telefoneTextField;
    // End of variables declaration//GEN-END:variables
}
